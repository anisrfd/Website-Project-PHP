<?php 
	$conn->close();
?>