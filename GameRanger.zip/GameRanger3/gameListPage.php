<!DOCTYPE html>
<html>
<head>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link href="themes/1/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/1/js-image-slider.js" type="text/javascript"></script>
</head>



<body>
   <marquee>welcome</marquee>

 <div class="container light">
<div class="wrapper">

<div id="logo_right">
<form>
 <input id="text_style" type="text" name="textbox">
 <input id="button" type="button" name="search" value="Search">
</form>
</div>
<div id="clear"></div>
</div>
</div>
 <!--main menu-->
 <ul>
     <li><a>Home</a></li>
     <li><a>Games</a>
         <ul>

             <li><a>Exclusives</a></li>
             <li><a>FPS</a></li>
             <li><a>RPG</a></li>
             <li><a>MULTIPLAYER</a></li>
             <li><a>PLATFORMER</a></li>
             <li><a>ACTION/ADVENTURE</a></li>


         </ul>
     </li>
     <li><a>Gears & Consoles</a>
         <ul>
             <li><a>Pc Peripherals</a></li>
             <li><a>Consoles</a></li>


         </ul>

     </li>
     <li><a>Contact Us</a>
         <ul>
             <li><a>Map</a></li>
             <li><a>Phone</a></li>
             <li><a>Email</a></li>
         </ul>
     </li>
     <li><a>About Us</a></li>
 </ul>


<p><br></p>
<p><br></p>
<p><br></p>



<h1> OUR EXCLUVIES GAMES </h1>


<div class= "gamelistsection">
    <ul class= "gameListGrid">
        <li>
            <div class=" box gameImage-1">
                <a href="overwatch.php">
                    <h3> Overwatch</h3>
                    <p> GOTY EDITION 70$ </p>
                </a>
            </div>
        </li>





 <li>
            <div class=" box gameImage-2">
                <a href="horizonzero.php">
                    <h3> Horizon zero</h3>
                    <p> Deulux EDITION 60$ </p>
                </a>
            </div>
        </li>




<li>
            <div class=" box gameImage-3">
                <a href="#">
                    <h3> Limbo</h3>
                    <p> GOTY EDITION 20$ </p>
                </a>
            </div>
        </li>




<li>
            <div class=" box gameImage-4">
                <a href="#">
                    <h3> COD WW2</h3>
                    <p> 65$ </p>
                </a>
            </div>
        </li>

        <li>
                    <div class=" box gameImage-5">
                        <a href="#">
                            <h3> Destiny 2</h3>
                            <p>  70$ </p>
                        </a>
                    </div>
                </li>

                <li>
                            <div class=" box gameImage-6">
                                <a href="#">
                                    <h3>NfS</h3>
                                    <p> GOTY EDITION 50$ </p>
                                </a>
                            </div>
                        </li>




    </ul>
</div>










</body>
</html>
