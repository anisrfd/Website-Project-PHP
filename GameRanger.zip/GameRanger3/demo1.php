<?php
	include 'config.php';
	/*
		1. mysql connection
		2. embedding php within html
	*/

?>



<!DOCTYPE html>
<html>
<head>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link href="themes/1/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/1/js-image-slider.js" type="text/javascript"></script>
</head>



<body>
   <marquee>

   <!--Welcome to GAME RANGER..This is a gaming site for crazy gamers..Email:khuparfd1212@gmail.com...-->
            <img src="images/2864187-acs_igbox.jpg"/>
            <img src="images/3167419-818tra9kb3l._ac_sl1500_.jpg"/>
            <img src="images/Battle-Alert-Empire-Defense-for-Android.jpg" />
            <img src="images/godofwar.jpg" />
		    <img src="images/header.jpg" />
			<img src="images/fury.jpg" />
			<img src="images/paladins-update-on-stream-giveaways-confirmed-on-community-streamer-day.jpg" />
			<img src="images/images.jpg"/>

   <!--Welcome to GAME RANGER..This is a gaming site for crazy gamers..Email:khuparfd1212@gmail.com...-->
   </marquee>

 <div class="container light">
<div class="wrapper">


	 <div class="container light">
	<div class="wrapper">

	<div id="logo_right">
	<form>
	 <input id="text_style" type="text" name="textbox">
	 <input id="button" type="button" name="search" value="Search">
	</form>
	</div>
	<div id="clear"></div>
	</div>
	</div>
 <!--main menu-->
    <ul id="menu">
        <li style="padding-left:35px"><a>Home</a></li>
        <li><a>Games</a>
        <ul>

                 <li><a href="gameListPage.html">Exclusives</a></li>
                <li><a href="fps.html">FPS</a></li>
                <li><a href="rpg.html">RPG</a></li>
                <li><a href="multiplayer.html">MULTIPLAYER</a></li>
                <li><a href="platformer.html">PLATFORMER</a></li>


            </ul>
        </li>
        <li><a>Gears & Consoles</a>
            <ul>
                <li><a href="pcPerpherals.html">Pc Peripherals</a></li>
                <li><a href="consoles.html">Consoles</a></li>


            </ul>

        </li>
        <li><a   href="#foo">Contact Us</a>
        <ul>


            </ul>
        </li>

</ul>




   <!--slide show -->
    <div id="sliderFrame">
        <div id="slider">

    <!--    Append this section to change the images -->
            <a href="#" target="_blank">
                <img src="images/actionimg1.jpg" alt="Welcome to GAME RANGER." />
            </a>

            <img src="images/car1.jpg" alt="" />
            <img src="images/GOD.jpg" alt="Keep calm and play" />
            <img src="images/image-slider-4.jpg" alt="Game and Chill" />
            <img src="images/madmax.jpg" />
						<img src="gameImage/cod.png" alt="" />

						<img src="gameImage/nfs.jpg" alt="Keep calm and play" />
						<img src="console/ps4Sao.jpg" alt="Keep calm and play" />



       </div>

    </div>

    <div id="clear"></div>

	<h1 style="margin-left:510px;color:white;">NEWS</h1>
	<div style="overflow:auto;
	border:5px solid white;
	color:black;
	font-family:italic;
	background-color:grey;
	width:1000px;
	height:480px;
	margin-bottom:100px;
	margin-left:200px;">
<h2>Over Watch Tournament:</h2>
Open Qualifiers</br>
Single Elimination Bo1. </br>
22nd & 23rd July. </br>
Top 4 of each qualifier advance
to group stage. </br>

Qualifier 1 (July 22, 3PM GMT) </br>
Qualifier 1 (July 22, 3PM GMT) </br>
Group Stage </br>
4 Teams in 4 Groups.</br>
Double Elimination Groups. </br>
26th July - 2nd August. </br>
Group Winners Qualify for Semi-Finals. </br>
This ensures the minimum of �300 in
winnings + travel accomodations for
offline finals.</br>
Final Stages </br>
Semi-Finals - August 9th. </br>
Grand Final - TBA.<a href="https://youtu.be/pYC44YPb_5k">Watch</a></br>

<h2>Paladins Community Tournaments:</h2>

Hey Paladins fans! We at Hi-Rez are happy to announce our first 5v5 community tournaments in both the North American and Brazilian Regions! Whether you�re a professional team or just want to come out with some friends and try your luck � all are welcome to come out and compete for their share of our 15,000 crystal prize pool. Let�s take a look at the details and how you can get involved.
</br>
Regions: North America & Brazil</br>

Dates:</br>
North America: Wednesday, June 14th</br>
Brazil: Thursday, June 15th</br>

Format: Single Elimination Open Bracket</br>
Teams will be randomly seeded into a single elimination style bracket</br>
Round 1 � Quarterfinals � Best of Three</br>
Semifinals + Finals � Best of Five</br>

Prizing: (per region)</br>
1st: 800 crystals per player</br>
2nd: 600 crystals per player</br>
3rd: 400 crystals per player</br>
4th: 400 crystals per player</br>
5th: 200 crystals per player</br>
6th: 200 crystals per player</br>
7th: 200 crystals per player</br>
8th: 200 crystals per player</br>

Total: 15,000 crystals</br>

How to get involved:</br>
Check-in�s: Have your team captain join our discord channel at the designated time below and check in with our <a href="https://discord.gg/BwhQwRD">administrators</a>
North America: Wednesday, June 14th</br>
Check in�s: 5:30pm � 6:30pm EDT</br>
Tournament start: 6:35pm EDT</br>

Brazil: Thursday, June 15th</br>
Check in�s: 12:00pm -1:00pm EDT</br>
Tournament start: 1:05pm EDT</br>

Broadcast Details: That�s right! We�ll be broadcasting the semi�s and finals of each tournament to show off some of the tournaments best matches.</br>

English Broadcast: Friday, June 16th @ 2pm EDT</br>
Brazil semis + finals</br>
NA semis + finals</br>
Portuguese Broadcast: Saturday, June 17th @ 2pm EDT</br>
Brazil semis + finals</br>
Please join our Paladins Community Tournament Facebook page for more information!</br>
We�re looking forward to some great games to celebrate our first tournaments and look forward to seeing you in the Realm!<a href="https://youtu.be/KBc3kOCivp8">Watch Final Match</a>

</br>




	</div>

	<div id="clear"></div>

	</div>



    <!--<div class="div2"></div>
    <footer id="footer">
      <h1>ALL RIGHT RESERVED BY ONLINE GAMING || Copyright 2017 || DHAKA || BANGLADESH</h1>
    </footer> -->

    <footer>
			<a name="foo">
    <div class="foot">

    <div class="social">
    <h3>Stay connected</h3>
    <a class="social youtube" href="https://www.youtube.com"> <img src="youtube1.jpg"/></a>

    <a class="social facebook" href="https://www.facebook.com"><img src="facebook1.jpg"/></a>

    <a class="social twitter" href="https://www.twitter.com"><img src="twitter1.jpg"/></a>
    </div>
    <div class="contact">
    <h3>Contact Us</h3>

    <form action="process.php" class="contact" method="get">
    <label for="name"> Name </label><br>
    <input class="text" name="name" type="text"/>
    <br><br>

    <label for="email"> Email </label><br>
    <input class="text" name="email" type="text"/>
    <br><br>

    <label for="message"> Message </label><br>
    <textarea class="message" name="message"></textarea>
    <br><br>
    <input class="submit" name="submit" type="submit" value="submit"/>

    </form>
    </div>

    </div>

    </footer>


</body>
</html>
<?php
	include 'close.php';
?>
