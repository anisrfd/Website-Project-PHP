<?php

include "connection.php";

$sql=" SELECT * FROM buyer";
$sql2=" SELECT * FROM message_info";
$sql3=" SELECT * FROM games";
$sql4=" SELECT * FROM pcperipherals";
$sql5=" SELECT * FROM consoles";



$query=mysql_query($sql) or die(mysql_error());
$query2=mysql_query($sql2) or die(mysql_error());
$query3=mysql_query($sql3) or die(mysql_error());
$query4=mysql_query($sql4) or die(mysql_error());
$query5=mysql_query($sql5) or die(mysql_error());

?>


<!DOCTYPE html>
<html>
    <head>

        <style>
		body{
			background:url(images/bg2.jpg);
		}
            table,tr,th,td
            {
				margin-left:150px;
				margin-top:30px;
                border: 1px solid black;
				background:white;
            }

        </style>
    </head>
    <body>
	<h1 style="margin-left:380px;color:white;font-size:40px;">Admin Panel</h1>
	<h2 style="margin-left:380px;color:white;"> Buyer Information</h2>
<table width="70%" cellpadding="5" cellspace="5" >
<tr>
<td><strong>Buyer Id</strong></td>
<td><strong>Email</strong></td>
<td><strong>Location</strong></td>
<td><strong>Credit card Number</strong></td>
<td><strong>Amount Spent</strong></td>
<td><strong>Product Id</strong></td>
</tr>

<?php while ($row=mysql_fetch_array($query)){?>
<tr>

<td><?php echo $row['buyerID']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo $row['location']; ?></td>
<td><?php echo $row['creditcardNum']; ?></td>
<td><?php echo $row['amountSpent']; ?></td>
<td><?php echo $row['product_id']; ?></td>
</tr>
<?php } ?>
</table>

<h2 style="margin-left:380px;color:white;"> Conact Information</h2>
<table width="70%" cellpadding="5" cellspace="5" >
<tr>
<td><strong>Id</strong></td>
<td><strong>Name</strong></td>
<td><strong>Email</strong></td>
<td><strong>Message</strong></td>

</tr>

<?php while ($row=mysql_fetch_array($query2)){?>
<tr>

<td><?php echo $row['Id']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo $row['message']; ?></td>

</tr>
<?php } ?>
</table>


<h2 style="margin-left:380px;color:white;"> Games List</h2>
<table width="70%" cellpadding="5" cellspace="5" >
<tr>
<td><strong>Game Id</strong></td>
<td><strong>Name</strong></td>
<td><strong>Price</strong></td>
<td><strong>Rating</strong></td>
<td><strong>Genre</strong></td>

</tr>

<?php while ($row=mysql_fetch_array($query3)){?>
<tr>

<td><?php echo $row['gameID']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['price']; ?></td>
<td><?php echo $row['rating']; ?></td>
<td><?php echo $row['genre']; ?></td>

</tr>
<?php } ?>
</table>



<h2 style="margin-left:380px;color:white;"> Consoles list</h2>
<table width="70%" cellpadding="5" cellspace="5" >
<tr>
<td><strong>Console Id</strong></td>
<td><strong>Name</strong></td>
<td><strong>Price</strong></td>

</tr>

<?php while ($row=mysql_fetch_array($query5)){?>
<tr>

<td><?php echo $row['consoleID']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['price']; ?></td>

</tr>
<?php } ?>
</table>


<h2 style="margin-left:380px;color:white;"> pcperipherals list </h2>
<table width="70%" cellpadding="5" cellspace="5" >
<tr>
<td><strong>Peripheral Id</strong></td>
<td><strong>Name</strong></td>
<td><strong>price</strong></td>

</tr>

<?php while ($row=mysql_fetch_array($query4)){?>
<tr>

<td><?php echo $row['pPeripheralID']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['price']; ?></td>
 
</tr>
<?php } ?>
</table>





</body>
</html>
