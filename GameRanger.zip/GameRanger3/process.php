<?php
	
	
	include 'config.php';
	
      
	$name = $_GET['name'];
	$email = $_GET['email'];
	$message = $_GET['message'];
	
	
	$sql = "INSERT INTO message_info (name,email,message) VALUES ('$name','$email','$message')";

	if ($conn->query($sql) === TRUE) {
		$last_id = $conn->insert_id;
		echo "New record created successfully. Last inserted ID is: " . $last_id;
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	include 'close.php';
?>

