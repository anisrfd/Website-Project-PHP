<?php


	include 'config.php';


	$email =$_GET['email'];
	$location =$_GET['location'];
	$creditcardNum =$_GET['cred_num'];
	$product_id=5;
	$amountSpent=60;

	$sql = "INSERT INTO buyer(email,location,creditcardNum,amountSpent,product_id) VALUES ('$email','$location','$creditcardNum','$amountSpent','$product_id')";

	if ($conn->query($sql) === TRUE) {
		$last_id = $conn->insert_id;
		echo "New record created successfully. Last inserted ID is: " . $last_id;
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}

	include 'close.php';
?>
