<!DOCTYPE html>
<html>
<head>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link href="themes/1/js-image-slider.css" rel="stylesheet" type="text/css" />
    <script src="themes/1/js-image-slider.js" type="text/javascript"></script>
</head>



<body>
   <marquee>welcome</marquee>

 <div class="container light">
<div class="wrapper">

<div id="logo_right">
<form>
 <input id="text_style" type="text" name="textbox">
 <input id="button" type="button" name="search" value="Search">
</form>
</div>
<div id="clear"></div>
</div>
</div>
 <!--main menu-->
 <ul id="menu">
     <li style="padding-left:35px"><a>Home</a></li>
     <li><a>Games</a>
     <ul>

              <li><a href="gameListPage.html">Exclusives</a></li>
             <li><a href="fps.html">FPS</a></li>
             <li><a href="rpg.html">RPG</a></li>
             <li><a href="multiplayer.html">MULTIPLAYER</a></li>
             <li><a href="platformer.html">PLATFORMER</a></li>


         </ul>
     </li>
     <li><a>Gears & Consoles</a>
         <ul>
             <li><a href="pcPerpherals.html">Pc Peripherals</a></li>
             <li><a href="consoles.html">Consoles</a></li>


         </ul>

     </li>
     <li><a   href="#foo">Contact Us</a>
     <ul>


         </ul>
     </li>

</ul>



<p><br></p>
<p><br></p>
<p><br></p>



<h1>Exclusive Pc Peripherals</h1>


<div class= "gamelistsection">
    <ul class= "gameListGrid">
        <li>
            <div class=" box pcImage-1">
                <a href="overwatch.html">
                    <h3> OCCULUS RIFT</h3>
                    <p> 250$ </p>
                </a>
            </div>
        </li>


        <li>
            <div class=" box pcImage-2">
                <a href="overwatch.html">
                    <h3> RAZER</h3>
                    <p> 500$ </p>
                </a>
            </div>
        </li>


        <li>
            <div class=" box pcImage-3">
                <a href="overwatch.html">
                    <h3> RACING KIT</h3>
                    <p> 200$ </p>
                </a>
            </div>
        </li>










    </ul>
</div>










</body>
</html>
